<?php
session_start();
echo "full_registration.php"."<br>";
//echo $_SESSION['user_x'];
include_once 'dropdown.php';

?>
<button class="btn_x btn-primary" style="padding:10px 10px 10px 10px">Continue To Become A Customer </button>