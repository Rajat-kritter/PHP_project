
<?php
include("header.php");
?>

	<div class="login">
		<div class="container">
			<h2>Login</h2>
		
<div class="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
				<form>
				<center><?php 
				include("social_login.php");?></center>
					<!--<input type="email" placeholder="Email Address" required=" " >
					<input type="password" placeholder="Password" required=" " >
					<div class="forgot">
						<a href="#">Forgot Password?</a>
					</div>
					<input type="submit" value="Login">-->
				</form>
			</div>
			
		</div>
	</div>
<!-- //login -->
<!-- //footer -->
<?php include 'footer.php';?>