
<?php

include("google/index.php");
include("facebook/index.php");

?>

