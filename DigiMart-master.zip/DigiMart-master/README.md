# DigiMart
E-commerce site that provides plateform for both customer and seller( service provider such as logomaking, 3D modelling, 2D modelling etc )
.
This is Project is done by Rajat verma (+918960516166, +919205330582)
